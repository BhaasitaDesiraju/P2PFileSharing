package main.java.messages;

public enum MessageType {
  CHOKE(0),
  UNCHOKE(1),
  INTERESTED(2),
  NOT_INTERESTED(3),
  HAVE(4),
  BITFIELD(5),
  REQUEST(6),
  PIECE(7);

  MessageType(int value) {
    byte messageVal = (byte) value;
  }
}
