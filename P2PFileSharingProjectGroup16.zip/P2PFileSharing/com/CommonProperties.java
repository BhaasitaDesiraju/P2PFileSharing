package com;

public class CommonProperties {
    public static int preferredNeighbourNumber;
    public static int IntervalForUnchoking;
    public static int optimumIntervalForUnchoking;
    public static String fileToBeShared;
    public static int sizeOfFile;
    public static int sizeOfPiece;
}